## Running
After installing all the dependencies int the requirements.txt the API needs you can start it from standing at the /API and executing the following prompt
```bash
uvicorn main:app --reload --port 9000
```

## Infos
This assignment was created by Fecsó András Balázs(xcf3r2@inf.elte.hu) on Linux Mint 22.1 Cinnamon. If you have any problems with starting the API, feel free to contact me. 

Also, the logging from the terminal has been moved to /API/output/uvicorn_app.log and there is the uvicorn and the other programs logs as well
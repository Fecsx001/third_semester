﻿using AsteroidGame.View;

namespace AsteroidGame.ViewModel
{

    public class DialogServiceAdapter : IDialogService
    {
        private readonly AsteroidGame.View.IDialogService _viewService;

        public DialogServiceAdapter(AsteroidGame.View.IDialogService viewService)
        {
            _viewService = viewService;
        }

        public void ShowMessage(string message, string title)
        {
            _viewService.ShowMessage(message, title);
        }

        public bool ShowConfirmation(string message, string title)
        {
            return _viewService.ShowConfirmation(message, title);
        }

        public string? ShowSaveDialog(string filter, string defaultExt, string initialDirectory)
        {
            return _viewService.ShowSaveDialog(filter, defaultExt, initialDirectory);
        }

        public string? ShowOpenDialog(string filter, string defaultExt, string initialDirectory)
        {
            return _viewService.ShowOpenDialog(filter, defaultExt, initialDirectory);
        }

        // Add or adapt any additional members from ViewModel.IDialogService here,
        // delegating to _viewService.
    }
}
﻿namespace AsteriodGameMechanic.Persistence;

public class AsteroidData
{
    public int X { get; set; }
    public int Y { get; set; }
    public int BaseSize { get; set; }
    public int Speed { get; set; }
}
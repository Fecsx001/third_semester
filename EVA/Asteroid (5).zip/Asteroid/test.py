def add_numbers(a, b=2, c):

     print(a + b + c)

add_numbers(a=1, c=3)
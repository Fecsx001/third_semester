﻿using AsteroidGameMechanic.Model;
using System;
using System.Collections.Generic;

namespace AsteroidGameMechanic.Persistance
{
    public interface IGamePersistence
    {
        void SaveGame(string filePath, GameModel gameModel);
        GameData LoadGame(string filePath);
    }
}
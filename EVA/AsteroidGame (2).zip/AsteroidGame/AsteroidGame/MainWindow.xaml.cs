﻿using System.Windows;
using AsteroidGame.ViewModel;

namespace AsteroidGame
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Loaded += MainWindow_Loaded;
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            if (DataContext is GameViewModel vm)
            {
                int width = (int)GameArea.ActualWidth;
                int height = (int)GameArea.ActualHeight;
                vm.SetSize(width, height);
            }
        }
    }
}
﻿using System.IO;
using System.Windows;
using System.Windows.Input;
using AsteroidGame.View;
using AsteroidGame.ViewModel;
using AsteroidGameMechanic.Persistance;

namespace AsteroidGame
{
    public partial class App : Application
    {
        private MainWindow _window;
        private GameViewModel _viewModel;
        
        public App()
        {
        }

        private void Application_Startup(object sender, StartupEventArgs e)
        {
            string appPath = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) ?? "";
            IHighScoreManager highScoreManager = new HighScoreManager(appPath);
            IGamePersistence persistence = new GamePersistence();
            
            IDialogService dialogService = new WpfDialogService();

            _viewModel = new GameViewModel(persistence, highScoreManager, dialogService);
            
            _viewModel.GameOver += OnGameOver;
            _viewModel.GameLoaded += OnGameLoaded;

            _window = new MainWindow
            {
                DataContext = _viewModel
            };
            
            _window.KeyDown += OnWindowKeyDown;
            _window.KeyUp += OnWindowKeyUp;
            _window.Closing += OnWindowClosing;
            
            _window.Show();
        }

        private void OnWindowKeyDown(object sender, KeyEventArgs e)
        {
            switch (e.Key)
            {
                case Key.Left:
                    _viewModel.SetMovingLeft(true);
                    break;
                case Key.Right:
                    _viewModel.SetMovingRight(true);
                    break;
                case Key.Space:
                    if (_viewModel.IsGameOver)
                    {
                        _viewModel.StartNewGame();
                    }
                    else
                    {
                        _viewModel.TogglePause();
                    }
                    break;
                case Key.Escape:
                    _window.Close();
                    break;
            }
        }
        
        private void OnWindowKeyUp(object sender, KeyEventArgs e)
        {
            switch (e.Key)
            {
                case Key.Left:
                    _viewModel.SetMovingLeft(false);
                    break;
                case Key.Right:
                    _viewModel.SetMovingRight(false);
                    break;
            }
        }
        
        private void OnWindowClosing(object? sender, System.ComponentModel.CancelEventArgs e)
        {
            _viewModel.StopGame();
        }


        private void OnGameOver(object? sender, EventArgs e)
        {
            string message = $"Game Over!\nTime: {_viewModel.GameTime:mm\\:ss}\nScore: {_viewModel.Score}";
            if (_viewModel.Score == _viewModel.HighScore && _viewModel.Score > 0)
            {
                message += "\n🎉 NEW HIGH SCORE! 🎉";
            }
            MessageBox.Show(message, "Game Over");
        }
        
        private void OnGameLoaded(object? sender, EventArgs e)
        {
            _window.Focus();
        }
    }
}
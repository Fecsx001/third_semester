﻿using Avalonia.Controls;

namespace ImageDownloaderAvalonia.Views;

public partial class MainView : UserControl
{
    public MainView()
    {
        InitializeComponent();
    }
}
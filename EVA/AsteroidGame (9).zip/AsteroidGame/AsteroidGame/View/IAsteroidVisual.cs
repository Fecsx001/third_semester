﻿namespace AsteroidGame.View
{
    public interface IAsteroidVisual
    {
        int Width { get; }
        int Height { get; }
    }
}


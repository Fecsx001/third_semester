﻿using System;

namespace ELTE.DocuStat.Persistence
{
    public interface IFileManager
    {
        string Load();
    }
}